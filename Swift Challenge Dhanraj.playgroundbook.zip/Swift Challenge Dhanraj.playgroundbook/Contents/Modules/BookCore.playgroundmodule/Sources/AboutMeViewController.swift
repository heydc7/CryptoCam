//
//  AboutMeViewController.swift
//  BookCore
//
//  Created by Dhanraj Sudhir Chavan on 18/04/21.
//

import UIKit

public class AboutMeViewController : UIViewController {
    
    let titleLabel : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 2
        lb.text = "Hey 👋\n I am Dhanraj Chavan."
        lb.textColor = UIColor.systemBlue.withAlphaComponent(0.8)
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 30)
        return lb
    }()
    
    let label2 : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 1
        lb.text = "I'm a Computer Science Student from India 🇮🇳"
        lb.textColor = UIColor.magenta.withAlphaComponent(0.8)
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        return lb
    }()
    
    let label3 : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 5
        lb.text = "Self Starter & Quick Learner\n I am very passionate about Coding & Technology, as well as shipping my ideas 💡 into apps 📲, Encouraging others to code through my Coding Blogs & YouTube Channel [Coding Potter]"
        lb.textColor = UIColor.systemPink.withAlphaComponent(0.75)
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 18)
        return lb
    }()
    
    let label4 : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 1
        lb.text = "Thank You for checking out my Swift Playground! 😊"
        lb.textColor = UIColor.systemBlue.withAlphaComponent(0.85)
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 22)
        return lb
    }()
    
    let imageView = UIImageView()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        setupLayout()
    }
    
    func setupLayout() {
        let image = UIImage(named: "dhanraj.png")
        
        self.imageView.translatesAutoresizingMaskIntoConstraints = false
        self.imageView.contentMode = .scaleAspectFit
        self.imageView.frame.size.width = 150
        self.imageView.frame.size.height = 150
        self.imageView.image = image
        
        self.view.addSubview(imageView)
        
        self.view.addSubview(titleLabel)
        self.view.addSubview(label2)
        self.view.addSubview(label3)
        self.view.addSubview(label4)
        
        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            imageView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 100),
            imageView.widthAnchor.constraint(equalToConstant: 150),
            imageView.heightAnchor.constraint(equalToConstant: 150),
            titleLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: self.imageView.bottomAnchor, constant: 32),
            label2.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            label2.topAnchor.constraint(equalTo: self.titleLabel.bottomAnchor, constant: 32),
            label3.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            label3.topAnchor.constraint(equalTo: self.label2.bottomAnchor, constant: 32),
            label3.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 16),
            label3.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -16),
            label4.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            label4.topAnchor.constraint(equalTo: self.label3.bottomAnchor, constant: 32)
        ])
    }
    
}


