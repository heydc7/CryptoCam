//
//  CamViewController.swift
//  BookCore
//
//  Created by Dhanraj Sudhir Chavan on 18/04/21.
//

import UIKit
import AVFoundation
import Vision
import PlaygroundSupport

public class CamViewController : UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    var player: AVAudioPlayer?
    var captureSession: AVCaptureSession?
    var previewLayer: AVCaptureVideoPreviewLayer?
    var previewView: UIView!
    var notificationViewCenterYAnchor : NSLayoutConstraint!
    
    var timer: Timer?
    
    // Constants
    let defaults = UserDefaults.standard
    
    let notificationView = UIView()
    let messageLabel = UILabel()
    
    let model : MobileNetV2 = {
        do {
            let config = MLModelConfiguration()
            return try MobileNetV2(configuration: config)
        } catch {
            print(error)
            fatalError("Can't Get ML Model")
        }
    }()
    
    // Data
    var topResults : [String] = []
    var topObservations : [VNClassificationObservation] = []
    
    var cryptoArr : [String:[String]] = [:]
    
    // UI
    let titleLabel : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 1
        lb.text = "CryptoCam"
        lb.textColor = .white
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 35)
        return lb
    }()
    
    let timeLabel : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 1
        lb.text = "5"
        lb.textColor = .white
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 200)
        return lb
    }()
    
    let stackView = UIStackView()
    
    let encryptBtn : UIButton = {
        let button = UIButton()
        button.setTitle("    Encrypt    ", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.isUserInteractionEnabled = true
        button.addTarget(self, action: #selector(handleEncryption), for: .touchUpInside)
        return button
    }()
    
    let decryptBtn : UIButton = {
        let button = UIButton()
        button.setTitle("    Decrypt    ", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
        button.backgroundColor = .systemRed
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.isUserInteractionEnabled = true
        button.addTarget(self, action: #selector(handleDecryption), for: .touchUpInside)
        return button
    }()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        showLiveCamera()
        setupLayouts()
        setupNotificationView()
        
        cryptoArr = defaults.object(forKey: "cryptoDict") as? [String : [String]] ?? [:]
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        previewLayer!.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        notificationViewAnimation()
    }
    
    // UI Setup
    func setupLayouts() {
        self.view.addSubview(titleLabel)
        
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.spacing = 25
        stackView.addArrangedSubview(encryptBtn)
        stackView.addArrangedSubview(decryptBtn)
        self.view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addSubview(timeLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 75),
            titleLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            stackView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            stackView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -120),
            timeLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            timeLabel.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        ])
    }
    
    func setupNotificationView() {
        self.view.addSubview(notificationView)
        notificationView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            notificationView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 50),
            notificationView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -50),
            notificationView.heightAnchor.constraint(equalToConstant: 70),
            notificationView.widthAnchor.constraint(equalToConstant: 100)
        ])
        
        notificationViewCenterYAnchor = notificationView.topAnchor.constraint(equalTo: self.titleLabel.bottomAnchor, constant: 20)
        notificationViewCenterYAnchor.isActive = true
        notificationView.layer.cornerRadius = 20
        notificationView.alpha = 1.0
        notificationView.backgroundColor = .white
        shadowToView(view: notificationView)
    }
    
    func setupMsgLabel() {
        self.view.addSubview(messageLabel)
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            messageLabel.leadingAnchor.constraint(equalTo: self.notificationView.leadingAnchor, constant: 5),
            messageLabel.trailingAnchor.constraint(equalTo: self.notificationView.trailingAnchor, constant: -5),
            messageLabel.topAnchor.constraint(equalTo: self.notificationView.topAnchor, constant: 5),
            messageLabel.bottomAnchor.constraint(equalTo: self.notificationView.bottomAnchor, constant: -5)
        ])
        
        messageLabel.text = "Tap on 'Encrypt' or Decrypt to Start"
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 2
    }
    
    func notificationViewAnimation() {
        notificationViewCenterYAnchor.constant = 10
        
        UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 4, options: .curveEaseOut) {
            self.view.layoutIfNeeded()
        } completion: { (_) in
            self.view.bringSubviewToFront(self.notificationView)
            self.setupMsgLabel()
        }
    }
    
    func showLiveCamera() {
        captureSession = AVCaptureSession()
        captureSession!.sessionPreset = .photo
        previewView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
        self.view.addSubview(previewView)
        let cameraDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
        guard let cameraInput = try? AVCaptureDeviceInput(device: cameraDevice!) else {return}
        if captureSession!.canAddInput(cameraInput) {
            captureSession!.addInput(cameraInput)
            let imageOutput = AVCaptureVideoDataOutput()
            imageOutput.setSampleBufferDelegate(self as AVCaptureVideoDataOutputSampleBufferDelegate, queue: DispatchQueue(label: "videoQueue"))
            if captureSession!.canAddOutput(imageOutput){
                captureSession!.addOutput(imageOutput)
                previewLayer = AVCaptureVideoPreviewLayer(session: captureSession!)
                previewLayer!.videoGravity = AVLayerVideoGravity.resize
                previewLayer!.connection?.videoOrientation = .landscapeRight
                let viewLayer: CALayer = self.previewView.layer
                viewLayer.addSublayer(self.previewLayer!)
                captureSession!.startRunning()
            }
        }
    }
    
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        connection.videoOrientation = .portrait
        guard let model = try? VNCoreMLModel(for: model.model) else { return }
        let request = VNCoreMLRequest(model: model) { (finishedRequest, error) in
            guard let results = finishedRequest.results as? [VNClassificationObservation] else { return }
            
            DispatchQueue.main.async(execute: {
                // self.timeLabel.text = "\(Observation.identifier)"
                self.topObservations = results
            })
        }
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        // executes request
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
    
    func shadowToView(view: UIView) {
        view.layer.shadowOffset = CGSize(width: 0, height: 3)
        view.layer.opacity = 0.6
        view.layer.cornerRadius = 10.0
        view.layer.shadowColor = UIColor.darkGray.cgColor
    }
    
    // Handle Buttons
    @objc private func handleEncryption() {
        self.encryptBtn.pulsate()
        var currentTime = Int(self.timeLabel.text!) ?? 0
        self.decryptBtn.isUserInteractionEnabled = false
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { (timer) in
            if currentTime != 0 {
                currentTime -= 1
                self.timeLabel.text = "\(currentTime)"
                self.messageLabel.text = "🔍 Scanning"
            } else {
                timer.invalidate()
                self.timeLabel.text = "5"
                self.messageLabel.text = "✅ Scanning Completed"
                for i in 0...2 {
                    self.topResults.append(String(self.topObservations[i].identifier.split(separator: ",")[0]))
                }
                self.playSuccessSound()
                self.encryptAlert()
                self.decryptBtn.isUserInteractionEnabled = true
            }
        }
    }
    
    @objc private func handleDecryption() {
        self.decryptBtn.pulsate()
        var currentTime = Int(self.timeLabel.text!) ?? 0
        self.encryptBtn.isUserInteractionEnabled = false
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { (timer) in
            if currentTime != 0 {
                currentTime -= 1
                self.timeLabel.text = "\(currentTime)"
                self.messageLabel.text = "🔍 Scanning"
            } else {
                timer.invalidate()
                self.timeLabel.text = "5"
                self.messageLabel.text = "✅ Scanning Completed"
                for i in 0...10 {
                    self.topResults.append(String(self.topObservations[i].identifier.split(separator: ",")[0]))
                }
                
                for (key,value) in self.cryptoArr {
                    for i in value {
                        if self.topResults.contains(i) {
                            self.playSuccessSound()
                            self.decryptAlert(title: "Object Decrypted", msg: "\n\n'\(key)'\n\n")
                            DispatchQueue.main.async {
                                self.messageLabel.text = "Object Decrypted Successfully 🥳"
                            }
                            self.encryptBtn.isUserInteractionEnabled = true
                            return
                        } else {
                            self.playFailSound()
                            self.decryptAlert(title: "Oops!", msg: "\n🤷🏻‍♂️\nObject Not Found\nplease scan again\n")
                            DispatchQueue.main.async {
                                self.messageLabel.text = "Not Found 🕵️‍♂️ Please Scan Again"
                            }
                            self.encryptBtn.isUserInteractionEnabled = true
                        }
                    }
                }
            }
        }
    }
    
    private func encryptAlert() {
        
        let alert = UIAlertController(title: "Encrypt Object", message: "Do you want to encrypt your message inside this object?\n\n\(self.topResults.joined(separator: ", "))\n\nif yes, add your message", preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "message"
            textField.isSecureTextEntry = true
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            
            let field = alert.textFields![0] as UITextField
            
            guard let msg = field.text else {return}
            
            self.cryptoArr[msg] = self.topResults
            self.defaults.set(self.cryptoArr, forKey: "cryptoDict")
            self.defaults.synchronize()
            
            DispatchQueue.main.async {
                self.messageLabel.text = "Message Encrypted Successfully 🔐"
            }
            
            self.topResults = []
            self.topObservations = []
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (_) in
            self.topResults = []
            self.topObservations = []
        }))
        
        self.present(alert, animated: true)
    }
    
    @objc private func decryptAlert(title: String, msg: String) {
        let alert = UIAlertController(title: "\(title)", message: "\(msg)", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: { (_) in
            self.topResults = []
            self.topObservations = []
        }))
        
        self.present(alert, animated: true)
    }
    
    func playSuccessSound() {
        guard let url = Bundle.main.url(forResource: "success", withExtension: "wav") else {return}
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            
            guard let player = player else {return}
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func playFailSound() {
        guard let url = Bundle.main.url(forResource: "error", withExtension: "wav") else {return}
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            
            guard let player = player else {return}
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
