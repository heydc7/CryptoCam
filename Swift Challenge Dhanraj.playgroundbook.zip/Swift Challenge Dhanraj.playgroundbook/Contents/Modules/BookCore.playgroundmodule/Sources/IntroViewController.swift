//
//  IntroViewController.swift
//  BookCore
//
//  Created by Dhanraj Sudhir Chavan on 18/04/21.
//

import UIKit

public class IntroViewController : UIViewController {
    
    let titleLabel : UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 1
        lb.text = "CryptoCam"
        lb.textColor = .black
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 25)
        return lb
    }()
    
    let imageView = UIImageView()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        setupLayout()
    }
    
    func setupLayout() {
        let image = UIImage(named: "logo.png")
        
        self.imageView.translatesAutoresizingMaskIntoConstraints = false
        self.imageView.contentMode = .scaleAspectFit
        self.imageView.frame.size.width = 150
        self.imageView.frame.size.height = 150
        self.imageView.image = image
        
        self.view.addSubview(imageView)
        
        self.view.addSubview(titleLabel)
        
        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: -50),
            imageView.widthAnchor.constraint(equalToConstant: 150),
            imageView.heightAnchor.constraint(equalToConstant: 150),
            titleLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: self.imageView.bottomAnchor, constant: 20)
        ])
    }
    
}
