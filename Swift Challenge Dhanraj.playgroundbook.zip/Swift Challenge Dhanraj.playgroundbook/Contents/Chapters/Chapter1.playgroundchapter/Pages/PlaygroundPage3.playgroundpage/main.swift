
/*:
 
 # Thank You!
 
 Thank You for checking out my Swift Playground 😊
 
 I aimed to create this playground to introduce a new concept of cryptography with Machine Learning ✨
 
 This Swift Playground introduces a new concept of **how Machine Learning can be used with Cryptography.**
 
 In the future, I aim to expand this demonstration to include **Machine Learning & Artificial Intelligence in Cryptography** to innovate the future of data security, data confidentiality, data integrity, user authentication. 👨🏻‍💻

 I am **Self Starter, Quick Learner, Passionate about Coding & Technology** as well as **shipping my ideas 💡 into apps 📲**, Encouraging others to **Code** through my **Coding Blogs & YouTube Channel [Coding Potter].**
 
 Thank You for your time ✨
 */

