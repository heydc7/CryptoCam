//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = CamViewController()
//#-end-hidden-code

/*:
 
 Welcome to CryptoCam 🎊
 =======================

 A Cam to Encrypt & Decrypt your data inside physical objects using Machine Learning
 
 */

/*:
 ## Run the Playground ▶️
 
 * Important: This page is best experienced in Landscape Mode with the LiveView in fullscreen.

 # Getting Started 🤩
 
 ## 1. Encryption
 * **Step 1:**
    * Click on the 'Encrypt' button & Hold the camera steady focusing on the Object.
    * It will start to analyze & classify the image of the objects in the camera frame.
    * After finishing the countdown, it will identify the name of the object in the camera frame using [Machine Learning Model](https://developer.apple.com/machine-learning/models/)
 
 * **Step 2:**
    * It will give an alert with the name of the identified object, please confirm the name of the object. If it's not correct, feel free to scan again.
    * In the Text Field, Add your message which you want to encrypt & tap on the 'Save' button.
    * Hurray! Your message is encrypted inside the object.
 
 ## 2. Decryption
 * **Step 1:**
    * Click on the 'Decrypt' button & Hold the camera steady focusing on Object.
    * It will start to analyze & classify the image of the objects in the camera frame.
    * After finishing the countdown, it will identify the name of the object in the camera frame using [Machine Learning Model](https://developer.apple.com/machine-learning/models/)
 * **Step 2:**
    * If the recognized object is found in CryptoData, it will decrypt your message.
    * After decrypting the message successfully, it will play Success sound. Otherwise, it will play Fail sound if the object is not found.
    * Hurray! The message is Decrypted.
 */

/*:
 ### Example:
 - Try scanning any MacBook 💻, add your message & click on the save to encrypt.
 - If you want to see the message that you have encrypted by scanning it, scan any Mac or Desktop, it will identify the object & show you the decrypted message ✨
 */

/*:
 **Credits:** [MobileNetV2](https://developer.apple.com/machine-learning/models/) Machine Learning Model is used from the **Apple Developer** website & Sounds from **freesounds.org**
 */

/*:
 Once you're done, let's [head over to the next page](@next) to know a little bit about me!
 */
