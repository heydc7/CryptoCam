/*:
###  WWDC 2021 : Swift Playground Submission
 
 A Swift Playground that aims to introduce & demonstrate a new concept of how Machine Learning 🤖 can be used with Cryptography 🔐 to innovate the future of Data Security, Data Confidentiality & Data Integrity.
*/

/*:
 # Overview
 
 Cryptography - the science of secret writing - is an ancient art.
 
 Cryptography is the study of techniques of secure communication, i.e. transmission of a message by a legitimate sender to the intended receiver, without allowing an adversary to cause any trouble.
 
 Cryptography is associated with the process of converting ordinary plain text into unintelligible text and vice-versa. It is a method of storing and transmitting data in a particular form so that only those for whom it is intended can read and process it. Cryptography not only protects data from theft or alteration, but can also be used for user authentication.

 */

/*:
 
 # Introducing CryptoCam 🎉
 
 **CryptoCam** is a camera for **Encrypting & Decrypting** the Data inside an Object using **Machine Learning Model**.
 
 */

/*:
 # How it works? 🤔
 
 **CryptoCam** uses Machine Learning Model to identify the image of an object & store an encrypted message with it. To decrypt the message, we have to scan the object to retrieve the message.

 Here is a Quick Overview of Working 👇🏻
 
 ![info image](info.png)
 
 * **Encryption:**
    * Scan the object
    * Identify the object name with ML
    * Add your message to encrypt it inside the object
 
 * **Decryption**:
    * Scan the object
    * Identify the object name with ML
    * Decrypt the message by scanning & identifying the same object
 
 */

/*:
 Once you're done, let's [head over to the next page](@next) to check out CryptoCam.
 */

/*:
 **Credits:** CryptoCam logo made with two icons from **FlatIcon**, Sounds from **freesounds.org**
 */

